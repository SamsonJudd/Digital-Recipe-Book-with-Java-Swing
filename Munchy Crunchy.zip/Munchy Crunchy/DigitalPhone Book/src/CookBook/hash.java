/**
 * The class 'hash' carries out the purpose of a hash function by using key-value pairs to implement recipes into the
 * interface.
 * @author Munchy Crunchy by Jennifer C., Roza P., Samson J., Ellie H.
 * @version Wednesday, April 27, 2022
 */

// package
package CookBook;

// import statements below
import java.util.Scanner;
import javax.swing.JOptionPane;

/**
The code for the public class 'hash' utilizes a string array and hash table in order to encode the recipe data and assign
it a unique, special key to pair it with its corresponding value.
 */
public class hash {
    Scanner scn = new Scanner(System.in);   // a scanner is initialized
    array[][] hashFirst;    // the variable 'hashFirst' is set as an array
    array head; // 'head' is an array
    static int counter; // 'counter' functions as an integer to track an object
    String[] yes={"Yes","No"};  // a string array with two options
    String text;    // 'text' is a string
    int hashed; // 'hashed' is an integer
    
    /*
    Cuisine
    [0] Italian
    [1] Japanese
    [2] American
    */

    /**
     * The code for the 'hash()' method uses the insert algorithm to add recipes into the program and use a hash function
     * to sort it by a unique key and its value. The variable 'hashFirst' is then printed out.
     */
    hash(){
        hashFirst = new array[2][100];
        System.out.println("==========================" + "\n|  MUNCHY CRUNCHY COOKBOOK |\n==========================");
        /*
         * The insert statements below serve to implement these specific recipes into the program's database, so that
         * they appear to the user when they first start up the program.
         */
        insert(2,"Mac and Cheese", "https://www.allrecipes.com/recipe/11679/homemade-mac-and-cheese/", "1");
        insert(0,"Chicken Marsala", "https://www.onceuponachef.com/recipes/chicken-marsala.html", "3");
        insert(1,"Takoyaki", "https://www.justonecookbook.com/takoyaki-recipe/", "5");
        insert(2,"Philly Cheesesteak", "https://natashaskitchen.com/philly-cheesesteak/", "3");
        insert(1,"Udon Noodle Soup", "https://www.justonecookbook.com/udon-noodle-soup/", "5");
        insert(0,"Parmesean Shrimp Penne", "https://www.delish.com/cooking/recipe-ideas/recipes/a50034/tuscan-shrimp-penne-recipe/", "2");
        insert(2,"S'mores", "https://www.hersheyland.com/recipes/hersheys-smores.html", "4");
        insert(0,"Calzone", "https://www.spendwithpennies.com/homemade-calzone/", "5");
        insert(1,"Matcha Marble Pound Cake", "https://www.justonecookbook.com/matcha-marble-pound-cake/", "4");
        int counter=counter("okay".toUpperCase());
        int anu=hashFunc(counter);
        System.out.println(hashFirst[1][anu]);
    }

    /**
     * The code for the method 'convert' takes in a string in order to convert the key of the key-value pair into a
     * legible word(s).
     * @param key : input is a string that represents the key in the key-value pair of a hash function
     * @return : output is a string of the converted input
     */
    String convert(String key){
        String first=key.substring(0,1).toUpperCase();
        first+=key.substring(1, key.length()).toLowerCase();
        return first;
    }

    /**
     * The code for the method 'counter' takes in a string variable and uses it to run a 'for' loop in order to add a
     * character into the integer 'temp'.
     * @param key : input is a string
     * @return : output is an integer representing the characters at 'i' from the 'for' loop
     */
    int counter(String key){
        int temp=0;
        for (int i = 0; i < key.length(); i++) {
            temp+=key.charAt(i);
        }
        return temp;
    }

    /**
     * The code for the method 'insert' takes in the variables needed to catalog each recipe and implements it into the
     * program in order for it to appear successfully in the user interface.
     * @param cuisine : input is an integer (0, 1, or 2) that correlates to a cuisine
     * @param recipeName : input is a string that represents the name of the recipe to be added
     * @param recipeLink : input is the hyperlink to the recipe in order to find the ingredients needed and instructions
     * @param rating : input is a string that represents the rating the user gives the recipe to indicate their judgment
     */
    void insert(int cuisine, String recipeName, String recipeLink, String rating){
        String first=convert(recipeName);
        array newNode = new array(cuisine,first,recipeLink,rating);
        int index=counter(first);
        int index2=counter(recipeLink.toUpperCase());
        int hash=hashFunc(index);
        int hash2=hashFunc(index2);
        while(hashFirst[0][hash]!=null && (!first.equals(hashFirst[0][hash].recipeName) || !recipeLink.toUpperCase().equals(hashFirst[0][hash].recipeLink))){
            hash=hashFunc(++hash);
        }
        while(hashFirst[1][hash2]!=null && (!first.equals(hashFirst[1][hash2].recipeName) || !recipeLink.toUpperCase().equals(hashFirst[1][hash2].recipeLink))){
            hash2=hashFunc(++hash2);
        }
        if(hashFirst[0][hash]!=null){
            int input=0;
            try{
                input=Integer.parseInt(JOptionPane.showInputDialog(null, hashFirst[0][hash].recipeName+" Already registered.\n1. Do you want to replace the existing recipe?"
                + "\n2. Or add a rating?\n\nAnswer:","Recipe is already registered.",JOptionPane.WARNING_MESSAGE));
                if(input>2){
                    JOptionPane.showMessageDialog(null, "Incorrect input! Operation cancelled.");
                }
            }catch(Exception e){
                JOptionPane.showMessageDialog(null, "Incorrect input! Operation cancelled.");
            }
            switch(input){
                case 1: 
                    hashFirst[0][hash]=newNode;
                    hashFirst[1][hash2]=newNode;
                    return;
                case 2: 
                    hashFirst[0][hash].rating+=", "+rating;
                    hashFirst[1][hash2].rating+=", "+rating;
                    return;
                default: System.out.println("Incorrect input! Operation cancelled.");return;
            }
        }else{
            hashFirst[0][hash]=newNode;
            hashFirst[1][hash2]=newNode;
        }
        System.out.println(first+" recipe added successfully. Please refresh to see updated cookbook.");
        counter++;
    }

    /**
     * The code for the method 'hashFunc' takes in an integer and returns its module remainder.
     * @param key : input is an integer
     * @return : output is an integer representing the remainder of the input
     */
    int hashFunc(int key){
        return (key%100);
    }

    /**
     * The code for the method 'setCounter' decrements the value of the 'counter' variable.
     */
    void setCounter(){
        counter--;
    }
    
}
