package CookBook;

import javax.swing.JOptionPane;

/**
 *
 * @author Samson, Roza, Jennifer, Ellie
 */
public class add extends javax.swing.JFrame { //creates a class add that extends javax.swing.JFrame

    /**
     * Creates new form add
     */
    private String recipeNm; //creates a private string recipeNm
    private String recipeLk; //creates a private string recipeLk
    private String rt; //creates a private string rt
    private int cuisineInteger; //creates a private int cuisineInteger

    /**
     * Initializes the java swing components of the add form and brings up the form
     */
    public add() {
        initComponents();
        setDefaultCloseOperation(javax.swing.WindowConstants.HIDE_ON_CLOSE);
        setDisabled();
    }

    /**
     * This method is called from within the constructor to initialize the form.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        /**
         * Initializes the java swing variables referenced later in the code
         */
        txtFirstName = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        txtLastName = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        txtNumber = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        btnAdd = new javax.swing.JButton();
        optCuisine = new javax.swing.JComboBox<>();
        jLabel5 = new javax.swing.JLabel();
        txtNumber1 = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();
        txtNumber2 = new javax.swing.JTextField();
        jLabel7 = new javax.swing.JLabel();
        txtNumber3 = new javax.swing.JTextField();
        jLabel8 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE); //sets default close operation
        setLocation(new java.awt.Point(180, 150)); //sets launch location of the window
        setResizable(false); //sets the window to be not resizable

        txtFirstName.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtFirstNameActionPerformed(evt);
            }
        });

        jLabel1.setFont(new java.awt.Font("Dialog", 1, 18)); // NOI18N
        jLabel1.setText("Create New Recipe"); //Sets the next of the create new recipe title to "create new recipe"

        jLabel2.setText("Recipe Name"); //Sets the text of the recipe name textbox to "recipe name"

        jLabel3.setText("Link");
        /**
         * adds a listener to see if an action is performed
         */
        txtNumber.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtNumberActionPerformed(evt);
            }
        });
        /**
         * adds a listener to see if keys are typed
         */
        txtNumber.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtNumberKeyTyped(evt);
            }
        });

        jLabel4.setText("Rating"); //sets the label of the rating textbox on the add form to "rating"

        btnAdd.setText("add"); //sets the text of the add button to add
        /**
         * adds a listener to see if a mouse is clicked
         */
        btnAdd.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                close(evt);
            }
        });
        /**
         * adds a listener to see if an action is performed
         */
        btnAdd.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAddActionPerformed(evt);
            }
        });

        optCuisine.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Italian", "Japanese", "American",})); //adds a dropdown select box with the cuisines Italian, Japanese, and American

        jLabel5.setText("Cuisine"); //sets the label of the cuisine select box on the add form to "cuisine"
        /**
         * adds a listener to see if an action is performed in a textbox
         */
        txtNumber1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtNumber1ActionPerformed(evt);
            }
        });
        /**
         * adds a listener to see if keys are typed
         */
        txtNumber1.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtNumber1KeyTyped(evt);
            }
        });
        /**
         * adds a listener to see if an action is performed in a textbox
         */
        txtNumber2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtNumber2ActionPerformed(evt);
            }
        });
        /**
         * adds a listener to see if keys are typed
         */
        txtNumber2.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtNumber2KeyTyped(evt);
            }
        });
/**
 * The code below builds the layout of the form using java swing.
 */
        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(24, 24, 24)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel8)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(txtNumber3, javax.swing.GroupLayout.PREFERRED_SIZE, 132, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel7)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(txtNumber2, javax.swing.GroupLayout.PREFERRED_SIZE, 132, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel6)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(txtNumber1, javax.swing.GroupLayout.PREFERRED_SIZE, 132, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel5)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(optCuisine, javax.swing.GroupLayout.PREFERRED_SIZE, 132, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jLabel1, javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel4)
                                    .addComponent(jLabel3)
                                    .addComponent(jLabel2))
                                .addGap(38, 38, 38)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(btnAdd)
                                    .addComponent(txtNumber, javax.swing.GroupLayout.PREFERRED_SIZE, 132, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(txtLastName, javax.swing.GroupLayout.PREFERRED_SIZE, 132, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(txtFirstName, javax.swing.GroupLayout.PREFERRED_SIZE, 132, javax.swing.GroupLayout.PREFERRED_SIZE))))
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addContainerGap(30, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(24, 24, 24)
                .addComponent(jLabel1)
                .addGap(31, 31, 31)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtFirstName, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel2))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtLastName, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel3))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtNumber, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel4))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtNumber1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel6))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtNumber2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel7))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtNumber3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel8))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(optCuisine, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel5))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 48, Short.MAX_VALUE)
                .addComponent(btnAdd)
                .addGap(18, 18, 18))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnAddActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAddActionPerformed
        main();
    }//GEN-LAST:event_btnAddActionPerformed
    
    
    private void txtFirstNameActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtFirstNameActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtFirstNameActionPerformed

    private void close(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_close
        setDefaultCloseOperation(javax.swing.WindowConstants.HIDE_ON_CLOSE);
    }//GEN-LAST:event_close

    private void txtNumberActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtNumberActionPerformed
        
    }//GEN-LAST:event_txtNumberActionPerformed

    private void txtNumber1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtNumber1ActionPerformed
        
    }//GEN-LAST:event_txtNumber1ActionPerformed

    private void txtNumber2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtNumber2ActionPerformed
        
    }//GEN-LAST:event_txtNumber2ActionPerformed

    private void txtNumberKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtNumberKeyTyped
        txtNumber1.setEnabled(true);
        btnAdd.setEnabled(true);
    }//GEN-LAST:event_txtNumberKeyTyped

    private void txtNumber1KeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtNumber1KeyTyped
        txtNumber2.setEnabled(true);
    }//GEN-LAST:event_txtNumber1KeyTyped

    private void txtNumber2KeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtNumber2KeyTyped
        txtNumber3.setEnabled(true);
    }//GEN-LAST:event_txtNumber2KeyTyped

    /**
     * The code below tries to add a recipe
     */
    void main(){
        try{
            this.recipeNm=txtFirstName.getText().trim(); //gets the text of the recipe name
            this.recipeLk=txtLastName.getText().trim(); //gets the text of the link
            this.rt=txtNumber.getText().trim(); //gets the text of the rating
            if(!txtNumber1.getText().equalsIgnoreCase("")){ //if the recipe name is blank
                this.rt+=", "+ txtNumber1.getText().trim();
            }
            if(!txtNumber2.getText().equalsIgnoreCase("")){ //if the link is blank
                this.rt+=", "+ txtNumber2.getText().trim();
            }
            if(!txtNumber2.getText().equalsIgnoreCase("")){ //if the rating is blank
                this.rt+=", "+ txtNumber3.getText().trim();
            }
            this.cuisineInteger=optCuisine.getSelectedIndex();
            if(exception()){
                JOptionPane.showMessageDialog(null, "Rating only contain numbers!","Incorrect input",JOptionPane.WARNING_MESSAGE); //If there are characters other than numbers in the rating textbox, show an error message
            }else{
                Main.hash.insert(cuisineInteger,recipeNm, recipeLk, rt);
                JOptionPane.showMessageDialog(null, "Recipe added successfully.", "Success!", JOptionPane.INFORMATION_MESSAGE); //If there are no problems, add the recipe successfully
                super.dispose();
            }
        }catch(Exception e){
            JOptionPane.showMessageDialog(null, "The recipe was not added successfully. Operation cancelled.", "Failure", JOptionPane.WARNING_MESSAGE); //If there are any of the problems above, show an error message
        }
    }

    /**
     * Disables textboxes
     */
    void setDisabled() {
        txtNumber1.setEnabled(false);
        txtNumber2.setEnabled(false);
        txtNumber3.setEnabled(false);
        btnAdd.setEnabled(false);
    }

    /**
    Boolean to see if there is a-z text in the text boxes on the form.
     */
    boolean exception(){
        if(
            txtNumber.getText().trim().matches(".*[a-zA-Z]+.*")||
            txtNumber1.getText().trim().matches(".*[a-zA-Z]+.*")||
            txtNumber2.getText().trim().matches(".*[a-zA-Z]+.*")||
            txtNumber3.getText().trim().matches(".*[a-zA-Z]+.*")
        ){
            return true;
        }
        return false;
    }
    public static void main(String args[]) {
        //uses Nimbus to set the look and feel
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(add.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(add.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(add.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(add.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new add().setVisible(true);
            }
        });
    }
    
    // Variables declaration
    private javax.swing.JButton btnAdd;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JComboBox<String> optCuisine;
    private javax.swing.JTextField txtFirstName;
    private javax.swing.JTextField txtLastName;
    private javax.swing.JTextField txtNumber;
    private javax.swing.JTextField txtNumber1;
    private javax.swing.JTextField txtNumber2;
    private javax.swing.JTextField txtNumber3;
    // End of variables declaration
}
