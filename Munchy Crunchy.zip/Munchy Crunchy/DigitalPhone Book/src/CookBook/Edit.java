/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package CookBook;

import javax.swing.JOptionPane;

/**
 *
 * @author Samson, Roza, Jennifer, Ellie
 */
public class Edit extends javax.swing.JFrame { //creates a class Edit that extends javax.swing.JFrame
    private int hash; //creates a private integer hash
    private int hash2; //creates a private integer hash2
    private String[] yes={"Yes","No. Check next."}; //creates a private string array ["yes, "No. Check next."]
    int comb; //creates an integer comb

    /**
     * Initializes the java swing components of the edit form and brings up the form
     */
    public Edit() {
        initComponents();
        setDefaultCloseOperation(javax.swing.WindowConstants.HIDE_ON_CLOSE);
        start();
    }

    /**
     * Function of the form
     */
    void main(){
        try{
            String first = Main.hash.convert(txtFindName.getText().trim()); //Creates a string that is equal to the recipes name found in the search
            int count = Main.hash.counter(first); //Initializes an integer and sets it equal to the hash counter for the searched recipe name
            hash=Main.hash.hashFunc(count); //sets hash equal to the main hash function for count
            array temp=Main.hash.hashFirst[0][hash]; //creates an array temp and sets it equal to the current recipe name
            while(Main.hash.hashFirst[0][Main.hash.hashFunc(hash+1)]!=null && Main.hash.hashFirst[0][hash+1].recipeName.equals(first)){ //While there are duplicate recipes that come up after searching for a recipe
                int hasil = JOptionPane.showOptionDialog(null, "There are multiple recipes with the same name."
                        + "Would you like to edit this recipe:\n"+ temp, "Collision", //Give an error message that there are multiple recipes with the same name
                JOptionPane.DEFAULT_OPTION, JOptionPane.WARNING_MESSAGE, null,
                yes, yes[1]);
                if(hasil==0) {
                    break;
                }else{
                    hash=Main.hash.hashFunc(++hash);
                }
            }
            temp=Main.hash.hashFirst[0][hash]; //sets temp equal to the current recipe
            
            int count2=Main.hash.counter(temp.recipeLink.toUpperCase()); //set the integer count2 equal to the hash counter for the searched recipe link
            hash2=Main.hash.hashFunc(count2); //set hash2 equal to the main hash function for count2
            while(Main.hash.hashFirst[1][hash2]!=temp && Main.hash.hashFirst[1][hash2]!=null){ //while there are no duplicate or blank recipes
                hash2=Main.hash.hashFunc(++hash2); //display the recipes matching the searched for recipe
            }
            /**
             * set the below textboxes to be enabled
             */
            setEnabled();
            txtFirst.setText(temp.recipeName);
            txtLast.setText(temp.recipeLink);
            txtNumb.setText(temp.rating);
            combKat.setSelectedIndex(temp.cuisineInteger);
        }catch(Exception e){ //catch an exception
            JOptionPane.showMessageDialog(null, "Recipe not found","Not Found",JOptionPane.ERROR_MESSAGE); //If there are no recipes matching the searched-for recipe, display an error message saying "recipe not found"
        }
    }

    /**
     * set the below textboxes to be enabled
     */
    void setEnabled(){
        btnSimpan.setEnabled(true);
        txtFirst.setEnabled(true);
        txtLast.setEnabled(true);
        txtNumb.setEnabled(true);
        combKat.setEnabled(true);
    }

    /**
     * Function to save an edited recipe
     */
    void save(){
        try{
            System.out.println(Main.hash.hashFirst[0][hash].recipeName +" deleted."); //Print that the recipe name was deleted
            Main.hash.hashFirst[0][hash]=null; //Set the recipe name to null
            Main.hash.hashFirst[1][hash2]=null; //Set the recipe link to null
            Main.hash.setCounter(); //Sets the counter
            
            String first=Main.hash.convert(txtFirst.getText().trim()); //Gets the trimmed text of the recipe name
            String last=txtLast.getText().trim().toUpperCase(); //Gets the trimmed text of the recipe link and converts it to upper case
            int cuisineInteger=combKat.getSelectedIndex(); //sets the int cuisineInteger equal to the cuisine of the recipe
            String numb=txtNumb.getText().trim(); //Sets the string numb equal to the rating of the recipe
            
            Main.hash.insert(cuisineInteger, first, last, numb); //attempts to replace the established recipe parameters with the edited recipe parameters
            JOptionPane.showMessageDialog(null, "Recipe updated successfully.","Info",JOptionPane.INFORMATION_MESSAGE); //Displays a message that says "recipe updated successfully."
            super.dispose();
        }catch(Exception e){ //If the program catches an exception
            JOptionPane.showMessageDialog(null, "Fail. Operation cancelled.","Failed",JOptionPane.ERROR_MESSAGE); //Display a message that says "Fail. Operation cancelled."
        }
    }

    /**
     * Starts up the edit form and sets the below textboxes to enabled
     */
    void start(){
        combKat.setEnabled(false);
        btnSimpan.setEnabled(false);
        txtFirst.setEnabled(false);
        txtLast.setEnabled(false);
        txtNumb.setEnabled(false);
    }
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        btnEdit = new javax.swing.JButton();
        txtFindName = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        txtFirst = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        txtLast = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        txtNumb = new javax.swing.JTextField();
        jLabel9 = new javax.swing.JLabel();
        combKat = new javax.swing.JComboBox<>();
        btnSimpan = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setLocation(new java.awt.Point(180, 150));
        setResizable(false);

        btnEdit.setText("Enter");
        btnEdit.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEditActionPerformed(evt);
            }
        });

        txtFindName.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtFindNameActionPerformed(evt);
            }
        });

        jLabel1.setFont(new java.awt.Font("Dialog", 1, 18)); // NOI18N
        jLabel1.setText("Edit recipe");

        jLabel2.setText("Find a recipe's name");

        jLabel3.setText("Recipe Name");

        txtFirst.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtFirstActionPerformed(evt);
            }
        });

        jLabel4.setText("Link");

        txtLast.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtLastActionPerformed(evt);
            }
        });

        jLabel5.setText("Rating");

        txtNumb.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtNumbActionPerformed(evt);
            }
        });

        jLabel9.setText("Cuisine");

        combKat.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Italian", "Japanese", "American" }));
        combKat.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                combKatActionPerformed(evt);
            }
        });

        btnSimpan.setText("Save");
        btnSimpan.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSimpanActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(24, 24, 24)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(0, 0, Short.MAX_VALUE)
                                .addComponent(btnSimpan, javax.swing.GroupLayout.PREFERRED_SIZE, 94, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabel9)
                                .addGap(127, 127, 127)
                                .addComponent(combKat, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel4)
                                    .addComponent(jLabel3)
                                    .addComponent(jLabel5))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 86, Short.MAX_VALUE)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                        .addComponent(txtLast, javax.swing.GroupLayout.DEFAULT_SIZE, 187, Short.MAX_VALUE)
                                        .addComponent(txtNumb))
                                    .addComponent(txtFirst, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 187, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(txtFindName)
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(jLabel2)
                                        .addGap(0, 0, Short.MAX_VALUE)))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(btnEdit)))
                        .addGap(24, 24, 24))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel1)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(24, 24, 24)
                .addComponent(jLabel1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel2)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtFindName, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnEdit))
                .addGap(31, 31, 31)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtFirst, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel3))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtLast, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel4))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtNumb, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel5))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel9)
                    .addComponent(combKat, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(33, 33, 33)
                .addComponent(btnSimpan, javax.swing.GroupLayout.PREFERRED_SIZE, 43, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(24, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents
    private void btnEditActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEditActionPerformed
        main();
    }//GEN-LAST:event_btnEditActionPerformed

    private void txtFindNameActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtFindNameActionPerformed
        
    }//GEN-LAST:event_txtFindNameActionPerformed

    private void txtFirstActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtFirstActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtFirstActionPerformed

    private void txtLastActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtLastActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtLastActionPerformed

    private void combKatActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_combKatActionPerformed
        
    }//GEN-LAST:event_combKatActionPerformed

    private void btnSimpanActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSimpanActionPerformed
        save();
    }//GEN-LAST:event_btnSimpanActionPerformed

    private void txtNumbActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtNumbActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtNumbActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Edit.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Edit.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Edit.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Edit.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Edit().setVisible(true);
            }
        });
    }

    // Variables declaration
    private javax.swing.JButton btnEdit;
    private javax.swing.JButton btnSimpan;
    private javax.swing.JComboBox<String> combKat;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JTextField txtFindName;
    private javax.swing.JTextField txtFirst;
    private javax.swing.JTextField txtLast;
    private javax.swing.JTextField txtNumb;
    // End of variables declaration
}
