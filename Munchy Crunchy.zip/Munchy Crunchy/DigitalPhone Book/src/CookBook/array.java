//creates an array that contains the recipe and its information

package CookBook;

public class array { // create class
    String recipeName; // create string recipe name
    String recipeLink; // create string link
    String rating; // create string rating
    int cuisineInteger; // create int that represents cuisine
   
    array(int cuisineInteger, String recipeName,String recipeLink, String rating){
        this.recipeName = recipeName; // set recipeName name to recipeName
        this.recipeLink = recipeLink.toUpperCase(); // set recipeLink to recipeLink + uppercase
        this.rating = rating; // set rating to rating
        this.cuisineInteger = cuisineInteger;// set cuisineInteger to cuisineInteger
    }
   
    array(String rating){
        this.rating = rating;// set rating to rating
    }
   
    public String toString(){
        if(recipeName == null) return rating;// if recipe is empty return rating
        return String.format("%s, %s \t- %s", recipeName,recipeLink, rating); // else return the information
    }
   
}
